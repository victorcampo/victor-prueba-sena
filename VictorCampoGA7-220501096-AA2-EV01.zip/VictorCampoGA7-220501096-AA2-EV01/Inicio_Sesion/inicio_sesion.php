<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de sesión</title>
    <link rel="stylesheet" href="stilos.css">
</head>
<body>

  

    <form action="codigo.php" method="post">

    <h1>Inicio de Sesión</h1>
    <p></p>
        <!-- Campo de Identificación -->
        <label for="identificacion">Identificación</label>
        <input type="text" id="identificacion" name="identificacion" required>
        <br><br>

           

<!-- Campo contrasena-->
<label for="contrasena">Contraseña</label>
        <input type="text" id="contrasena" name="contrasena" required>
        <br><br>

        <!-- Botones de Registro y Cancelar -->
        <button type="submit" name="submit">Iniciar Sesión</button>
        <button type="reset">Cancelar</button>
    </form>

</body>
</html>