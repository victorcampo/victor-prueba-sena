<?php
// Verificar si el formulario ha sido enviado
if (isset($_POST['submit'])) {

    // Conexión a la base de datos (localhost, usuario 'root' sin contraseña)
    $conn = new mysqli('localhost', 'root', '', 'registro');

    // Verificar si la conexión es exitosa
    if ($conn->connect_error) {
        die("Error en la conexión: " . $conn->connect_error);
    }

    // Obtener los valores del formulario
    $identificacion = $_POST['identificacion'];
    $tipo_identificacion = $_POST['tipo_identificacion'];
    $nombre_completo = $_POST['nombre_completo'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $correo = $_POST['correo'];
    $rol = $_POST['rol'];
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT); // Encriptar la contraseña

    // Preparar la consulta SQL para insertar los datos
    $sql = "INSERT INTO registro (identificacion, tipo_identificacion, nombre_completo, fecha_nacimiento, correo, rol, contrasena)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Preparar la sentencia
    $stmt = $conn->prepare($sql);

    // Vincular los parámetros a la sentencia preparada
    $stmt->bind_param("sssssss", $identificacion, $tipo_identificacion, $nombre_completo, $fecha_nacimiento, $correo, $rol, $contrasena);

    // Ejecutar la sentencia
    if ($stmt->execute()) {
        echo "Registro exitoso.";
    } else {
        echo "Error en el registro: " . $stmt->error;
    }

    // Cerrar la sentencia y la conexión
    $stmt->close();
    $conn->close();
}
?>