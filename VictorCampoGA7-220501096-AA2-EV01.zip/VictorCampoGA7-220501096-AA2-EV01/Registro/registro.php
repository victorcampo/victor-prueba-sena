<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Datos</title>
    <link rel="stylesheet" href="stilos.css">
</head>
<body>

  

    <form action="codigo.php" method="post">

    <h1>Formulario de Registro</h1>
    <p></p>
        <!-- Campo de Identificación -->
        <label for="identificacion">Identificación</label>
        <input type="text" id="identificacion" name="identificacion" required>
        <br><br>

        <!-- Campo Tipo de Documento -->
        <label for="tipo_identificacion">Tipo de Documento</label>
        <select id="tipo_identificacion" name="tipo_identificacion" required>
            <option value="cc">CC</option>
            <option value="ti">TI</option>
            <option value="ce">CE</option>
            <option value="pasaporte">PE</option>
        </select>
        <br><br>

        <!-- Campo Nombre Completo -->
        <label for="nombre_completo">Nombre Completo</label>
        <input type="text" id="nombre_completo" name="nombre_completo" required>
        <br><br>

        <!-- Campo Fecha de Nacimiento -->
        <label for="fecha_nacimiento">Fecha de Nacimiento</label>
        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>
        <br><br>

        <!-- Campo Correo -->
        <label for="correo">Correo Electrónico</label>
        <input type="email" id="correo" name="correo" required>
        <br><br>

        <!-- Campo Rol -->
        <label for="rol">Rol</label>
        <select id="rol" name="rol" required>
            <option value="admin">Administrador</option>
            <option value="usuario">Usuario</option>
        </select>
        <br><br>

<!-- Campo contrasena-->
<label for="contrasena">Contraseña</label>
        <input type="text" id="contrasena" name="contrasena" required>
        <br><br>

        <!-- Botones de Registro y Cancelar -->
        <button type="submit" name="submit">Registrar</button>
        <button type="reset">Cancelar</button>
    </form>

</body>
</html>